<?
	session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/common.css">
	<style>
		button{
			border-radius:15px;
			width:50%;
			height:50%;
			padding:50px;
		}
		th{
			height:50%;
			width:10%;
		}
		td{
			width:40%;
			height:30%;
		}
		.kbo{
			background-image:url(kbo.jpg);
			background-repeat: no-repeat;
			background-position:center;
		}
	</style>
</head>
<body>

	<div id="header">
    <? include "./lib/keep-login.php"; ?>
	</div>
<div>
<a href="./free/list.php" style="font-size:25px;":>post</a>
</div>
	<center><img style="width:40%;height:10%;" src="./9조 최종/9조 로고.png"></center>
	<table border="1" class="kbo">
		<tr>
			<th rowspan="2"><img src="./9조 최종/류현진.gif" style="height:80%; width:100%;"></th>
			<td><center><a href="./9/uniform.html"><button><b style="font-size:30px;">유니폼</b></button></center></a></td>
			<td><center><a href="./9/cloth.html"><button><b style="font-size:30px;">의류</b></button></center></a></td>
			<th rowspan="2"><img src="./9조 최종/김태균.gif" style="height:100%; width:100%;"></th>
		</tr>
		<tr>
			<td><center><a href="./9/equipment.html"><button><b style="font-size:30px;">장비</b></button></a></center></td>
			<td><center><a href="./9/etc.html"><button><b style="font-size:30px;">기타</b></button></a></center></td>
		</tr>
	</table>
</body>
</html>
